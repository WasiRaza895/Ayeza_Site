"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Heart, Mail } from "lucide-react"

const messages = [
  "I still remember how your laughter made me feel at our very first call... Every time I miss you, I count the minutes until I see you again.",
  "Your laugh makes me happy always, and it brightens my day. I love how you dance around the room when you're happy.",
  "You are so kind, and you always help me see the good in life. I'm sorry I wasn't more thoughtful.",
  "Your voice is my favorite sound, and I wish I could hear it right now.",
  "I miss you more than words can say, and every day I think of how lucky I am. You are my inspiration, your kindness makes me a better person.",
  "You make me want to be a better person, and I promise to try harder every day. I'm sorry I let my faults get in the way. I'm not perfect, but I promise I'm always trying to be better for you.",
  "Being with you in my mind makes me the happiest I have ever been. I'm sorry I didn't show you that enough.",
  "Your kindness makes me proud to call you mine. You don't even know how precious you are to me, Ayeza. My heart beats a little slower when you're mad at me.",
  "Every moment with you is a treasure I keep in my heart. I'm sorry I ever acted careless.",
  "Ayeza, you are my everything, and I will never stop loving you. I'm sorry I let a simple birthday slip by without enough effort.",
]

const romanticWords = ["love", "darling", "sweetheart", "my world", "always", "forever", "my heart"]

const cardColors = ["#FFC0CB", "#E6E6FA"] // Pale Pink and Lavender

// Background Word Component
function FloatingWord({ word, index }: { word: string; index: number }) {
  const [isHovered, setIsHovered] = useState(false)

  const initialX = Math.random() * 80 + 10
  const initialY = Math.random() * 80 + 10

  return (
    <motion.div
      className="absolute text-4xl md:text-5xl font-inter text-gray-800 opacity-10 select-none pointer-events-auto cursor-pointer"
      style={{
        top: `${initialY}%`,
        left: `${initialX}%`,
      }}
      animate={
        isHovered
          ? {
              scale: 1.3,
              opacity: 0.4,
              x: Math.random() * 200 - 100,
              y: Math.random() * 200 - 100,
            }
          : {
              y: [0, -15, 0],
              opacity: [0.08, 0.15, 0.08],
              scale: 1,
              x: 0,
            }
      }
      transition={
        isHovered
          ? {
              duration: 0.6,
              ease: "easeOut",
              type: "spring",
              stiffness: 100,
            }
          : {
              duration: 8 + Math.random() * 4,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }
      }
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      {word}
    </motion.div>
  )
}

export default function UnlockMyHeart() {
  const [currentStep, setCurrentStep] = useState("landing") // 'landing', 'messages', 'final'
  const [currentIndex, setCurrentIndex] = useState(0)
  const [showVideo, setShowVideo] = useState(false)

  const handleStart = () => {
    setCurrentStep("messages")
  }

  const handleNext = () => {
    if (currentIndex < messages.length - 1) {
      setCurrentIndex(currentIndex + 1)
    } else {
      setCurrentStep("final")
    }
  }

  const handleReveal = () => {
    setShowVideo(true)
  }

  const handleWatchAgain = () => {
    const video = document.querySelector("video") as HTMLVideoElement
    if (video) {
      video.currentTime = 0
      video.play()
    }
  }

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-pink-50 via-purple-50 to-pink-100">
      {/* Background Tilted Words - Interactive */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {romanticWords.map((word, index) => (
          <FloatingWord key={`${word}-${index}`} word={word} index={index} />
        ))}
      </div>

      {/* Landing Section */}
      <AnimatePresence>
        {currentStep === "landing" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center min-h-screen px-4 text-center relative z-10"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="mb-8"
            >
              <Heart className="w-16 h-16 text-pink-500 mx-auto mb-4" />
              <h1 className="text-3xl md:text-5xl font-poppins font-bold text-gray-800 mb-6">
                For Ayeza, the one who holds my heart
              </h1>
            </motion.div>

            <motion.button
              onClick={handleStart}
              className="bg-pink-600 hover:bg-pink-700 text-white font-poppins font-semibold px-8 py-4 rounded-full text-lg transition-all duration-200 transform hover:scale-105 active:scale-95"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              animate={{
                scale: [1, 1.05, 1],
              }}
              transition={{
                duration: 2,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
              }}
            >
              Start Your First Message
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Message Cards */}
      <AnimatePresence>
        {currentStep === "messages" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center min-h-screen px-4 relative z-10"
          >
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="w-full max-w-md mx-auto"
            >
              <div
                className="rounded-lg shadow-lg p-6 mb-6 relative"
                style={{ backgroundColor: cardColors[currentIndex % 2] }}
              >
                <motion.div
                  whileHover={{ boxShadow: "0 8px 25px rgba(0, 0, 0, 0.15)" }}
                  className="transition-shadow duration-300"
                >
                  <p className="text-gray-800 font-inter text-lg leading-relaxed mb-6">{messages[currentIndex]}</p>

                  <div className="text-center">
                    <motion.button
                      onClick={handleNext}
                      className="bg-pink-600 hover:bg-pink-700 text-white font-poppins font-medium px-6 py-3 rounded-full transition-all duration-200"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      animate={{
                        scale: [1, 1.05, 1],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "easeInOut",
                      }}
                    >
                      Next
                    </motion.button>
                  </div>
                </motion.div>
              </div>

              {/* Progress Indicator */}
              <div className="text-center">
                <p className="text-gray-700 font-inter text-sm mb-2">Message {currentIndex + 1} of 10</p>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-pink-600 h-2 rounded-full"
                    initial={{ width: "0%" }}
                    animate={{ width: `${((currentIndex + 1) / 10) * 100}%` }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                  />
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Final Reveal Section */}
      <AnimatePresence>
        {currentStep === "final" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center min-h-screen px-4 text-center relative z-10"
          >
            {!showVideo ? (
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 1, type: "spring", bounce: 0.3 }}
                className="cursor-pointer"
                onClick={handleReveal}
              >
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }}
                >
                  <Mail className="w-32 h-32 text-pink-500 hover:text-pink-600 transition-colors duration-300" />
                </motion.div>
                <p className="text-gray-700 font-inter text-lg mt-4">Click to unlock your final message</p>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="w-full max-w-2xl"
              >
                <div className="bg-white rounded-lg shadow-xl p-6 mb-6">
                  <video className="w-full rounded-lg shadow-lg mb-4" controls autoPlay src="/placeholder-video.mp4">
                    Your browser does not support the video tag.
                  </video>

                  <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1, duration: 0.6 }}
                    className="text-gray-800 font-inter text-lg leading-relaxed mb-4"
                  >
                    I love you more than words can say. Thank you for unlocking my heart.
                  </motion.p>

                  <motion.button
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.5, duration: 0.6 }}
                    onClick={handleWatchAgain}
                    className="bg-pink-600 hover:bg-pink-700 text-white font-poppins font-medium px-6 py-3 rounded-full transition-all duration-200 transform hover:scale-105 active:scale-95"
                  >
                    Watch Again
                  </motion.button>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <div className="fixed bottom-4 left-0 right-0 text-center relative z-10">
        <p className="text-gray-600 font-inter text-sm">Made with all my love for Ayeza</p>
      </div>
    </div>
  )
}
